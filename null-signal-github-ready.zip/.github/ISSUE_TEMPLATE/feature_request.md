---
name: Feature request
about: Suggest an improvement or new mystery element
title: "[Feature] "
labels: enhancement
assignees: ""
---

## The idea
What would you like to add?

## Why it fits
How would this improve the experience or mystery?

## Extra context
Mock-ups, story snippets, or examples are welcome.
