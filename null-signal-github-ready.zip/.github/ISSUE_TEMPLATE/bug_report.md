---
name: Bug report
about: Report something that is not working
title: "[Bug] "
labels: bug
assignees: ""
---

## What happened?
Describe the bug clearly.

## Steps to reproduce
1.
2.
3.

## Expected behaviour
What did you expect to happen?

## Browser and device
- Browser:
- Operating system:
- Desktop or mobile:

## Console errors
If relevant, paste any browser-console errors here.
