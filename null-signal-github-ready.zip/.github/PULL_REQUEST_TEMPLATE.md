## What changed?
Describe the changes in this pull request.

## Why?
What problem does it solve or what does it improve?

## Testing
- [ ] Opened `index.html` and tested the changed behaviour
- [ ] Checked a narrow/mobile viewport
- [ ] Checked the browser console
- [ ] Updated documentation if needed

## Screenshots
Add screenshots for visual changes, if useful.
